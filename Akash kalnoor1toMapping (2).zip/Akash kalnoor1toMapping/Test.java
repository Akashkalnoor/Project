package com.test;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

 public class Test {
	 
  public static void main(String[] args) {
       Employee e1 = new Employee();
        e1.setName("akash");
        e1.setEmail("akash@gmail.com");
        Employee e2 = new Employee();
        e2.setName("kaustub");
        e2.setEmail("kaustub@gmail.com");
        Employee e3 = new Employee();
        e3.setName("Mahesh");
        e3.setEmail("mahesh@gmail.com");
       
 
        Address address1 = new Address();
        address1.setCity("kalaburagi");
        address1.setState("Karnataka");
        address1.setCountry("India");
        address1.setPinCode("585101");
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml"); // load the file
        SessionFactory sessionFactory =configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        e1.setAddress(address1);
        e2.setAddress(address1);
        e3.setAddress(address1);
        session.save(e1);
        session.save(e2);
        session.save(e3);
        transaction.commit();
        session.close();
        sessionFactory.close();
        
      }

 }

